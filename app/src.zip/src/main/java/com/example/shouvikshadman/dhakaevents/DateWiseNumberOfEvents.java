package com.example.shouvikshadman.dhakaevents;

/**
 * Created by Shouvik Shadman on 3/30/2016.
 */
public class DateWiseNumberOfEvents {
    int num;

    public DateWiseNumberOfEvents() {
        // empty default constructor, necessary for Firebase to be able to deserialize blog posts
    }

    public  int getNum() {
        return num;
    }
}
