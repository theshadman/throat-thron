package com.example.shouvikshadman.dhakaevents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.util.HashMap;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {
    EditText ed1,ed2;
    Button bt1;
    String username,password;
    Firebase rootRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Firebase.setAndroidContext(this);
        rootRef = new Firebase("https://brilliant-fire-6231.firebaseio.com/");
        ed1=(EditText)findViewById(R.id.editText);
        ed2=(EditText)findViewById(R.id.editText2);
        bt1=(Button)findViewById(R.id.button);
    }

    public void admitInformation(View view){
        username=ed1.getText().toString();
        password=ed2.getText().toString();
        Firebase myThing= rootRef.child("members");
        Firebase pushdata=myThing.push();
        Map<String, String> post1 = new HashMap<String, String>();
        post1.put("name", username);
        post1.put("password", password);
        pushdata.setValue(post1);
        System.out.println(pushdata.getKey().toString());
        Toast toast = Toast.makeText(getApplicationContext(), "Success in Creating a new account!!!", Toast.LENGTH_SHORT);
        toast.show();
        Intent i=new Intent(this,EventListActivity.class);
        startActivity(i);
    }


}
